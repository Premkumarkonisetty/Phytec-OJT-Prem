#include<stdio.h>
int main()
{
	printf("heloo rugudbord");
	return 0;
}
