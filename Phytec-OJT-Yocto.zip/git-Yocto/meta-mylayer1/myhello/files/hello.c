#include<stdio.h>

int main()
{
	printf("This is yocto Project");
	return 0;
}
