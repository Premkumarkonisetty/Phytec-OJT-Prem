#include "stm32f4xx.h"

void  timedelay(int n)
{
		//int i;
		//for(;n>0;n--)
		for(int i=0;i<n*3195;i++);
}
