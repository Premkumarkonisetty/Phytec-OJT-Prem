#include"stm32f4xx.h"

int main()
{
	RCC ->AHB1ENR |=1;
	RCC ->AHB1ENR |= 1<<2;

	//GPIOA->MODER &=0;//clean
	GPIOA->MODER |=(1<<10);//set
	//GPIOC ->MODER &=0; //clean

	while(1)
	{

	if(GPIOC ->IDR &(1<<13))
		GPIOA->BSRR |=~(1<<5);

	else

	 GPIOA->BSRR |=(1<<5);
	}
}

