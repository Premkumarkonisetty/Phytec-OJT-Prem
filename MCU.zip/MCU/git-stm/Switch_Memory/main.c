
#include "Memory.h"


int main(void) {

	Enable();
	ledblink();

while(1)
{

	clickbutton();
}
}
