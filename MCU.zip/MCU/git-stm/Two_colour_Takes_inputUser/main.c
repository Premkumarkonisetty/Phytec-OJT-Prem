#include "stm32f4xx_hal.h"

// Define the GPIO pins for the LED
#define RED_PIN GPIO_PIN_0
#define GREEN_PIN GPIO_PIN_1
#define BLUE_PIN GPIO_PIN_4
#define LED_PORT GPIOA

// Define the GPIO pin for the button
#define BUTTON_PIN GPIO_PIN_13
#define BUTTON_PORT GPIOC

// Function to initialize the GPIO pins for the LED
void LED_Init(void) {
    // Enable the GPIO clock
    __HAL_RCC_GPIOA_CLK_ENABLE();

    // Configure GPIO pins as output
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.Pin = RED_PIN | GREEN_PIN | BLUE_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; // Output push-pull mode
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);
}

// Function to initialize the GPIO pin for the button
void Button_Init(void) {
    // Enable the GPIO clock for the button
    __HAL_RCC_GPIOC_CLK_ENABLE();

    // Configure GPIO pin as input with pull-up
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.Pin = BUTTON_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(BUTTON_PORT, &GPIO_InitStruct);
}

int main(void) {
    HAL_Init();

    LED_Init();
    Button_Init();

    uint8_t ledState = 1; // 0 - OFF, 1 - ON

    while (1) {
        // Check the state of the button
        if //(HAL_GPIO_ReadPin(BUTTON_PORT, BUTTON_PIN) == GPIO_PIN_SET)
        	 (HAL_GPIO_ReadPin(BUTTON_PORT,BUTTON_PIN) == GPIO_PIN_RESET)
        {
            // Button is pressed, toggle the LED state
            if (ledState == 1)
            {
                // LED is ON, turn it OFF
            	 HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_SET);
            	        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_RESET);

            	        HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_SET);
            	        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_RESET);

            	        HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_SET);

                ledState = 0;
            } else
            {
                // LED is OFF, turn it ON
            	 HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_RESET);
            	        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_RESET);
                ledState = 1;
            }

            // Add a small delay to debounce the button (adjust as needed)
            HAL_Delay(1000);
        }
    }
}
