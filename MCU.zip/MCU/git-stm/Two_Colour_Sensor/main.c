#include "stm32f4xx_hal.h"

// Define the GPIO pins for the LED
#define RED_PIN GPIO_PIN_0
#define GREEN_PIN GPIO_PIN_1
#define BLUE_PIN GPIO_PIN_4
#define LED_PORT GPIOA

// Function to initialize the GPIO pins for the LED
void LED_Init(void) {
    // Enable the GPIO clock
    __HAL_RCC_GPIOA_CLK_ENABLE();

    // Configure GPIO pins as output
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.Pin = RED_PIN | GREEN_PIN | BLUE_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; // Output push-pull mode
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);
}

int main(void) {
    HAL_Init(); // Initialize HAL Library

    LED_Init(); // Initialize the LED GPIO pins

    while (1) {
        // Red
        HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_RESET);
        HAL_Delay(2000);  // Delay for 1 second

        // Green
        HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_RESET);
        HAL_Delay(2000);  // Delay for 1 second

        // Blue
        HAL_GPIO_WritePin(LED_PORT, RED_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LED_PORT, GREEN_PIN, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LED_PORT, BLUE_PIN, GPIO_PIN_SET);
        HAL_Delay(2000);  // Delay for 1 second




    }
}


