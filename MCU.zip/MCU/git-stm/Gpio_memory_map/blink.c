#include "stm32f4xx.h"

void led_on()
{
	GPIOA->ODR |= (1<<5);
}
void led_off()
{
	GPIOA->ODR &= ~(1<<5);
}

