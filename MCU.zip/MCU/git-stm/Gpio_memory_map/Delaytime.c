#include "stm32f4xx.h"

void  timedelay(int n)
{

		for(int i=0;i<n*3195;i++);
}
