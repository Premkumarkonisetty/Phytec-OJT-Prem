#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	printf("Enter the name:");
	gets(str);
	char *token=strtok(str," ");

	while(token!=NULL)
	{
		printf("%s",token);
		token = sstrtok(NULL," ");
		if(token!=NULL)
		{
			printf(",");
		}
	}
	return 0;
}
