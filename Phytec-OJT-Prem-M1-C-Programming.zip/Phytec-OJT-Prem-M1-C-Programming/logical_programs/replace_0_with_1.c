#include <stdio.h>

int main() 
{
    unsigned int inputNumber;

    // Input a number
    printf("Enter a number: ");
    scanf("%u", &inputNumber);

    unsigned int result = 0;
    unsigned int placeValue = 1;

    // Replace all 0's with 1's
    while (inputNumber > 0)  //90003 
    {
        int digit = inputNumber % 10;   //3
        if (digit == 0) {
            result += placeValue;
        } else {
            result += digit;    //3
        }
        placeValue *= 10;  //
        inputNumber /= 10;  
    }

    // Output the result
    printf("Number with replaced 0's: %u\n", result);

    return 0;
}
