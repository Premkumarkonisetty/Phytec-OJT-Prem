#include<stdio.h>
#include<string.h>
int main()
{
	char a[20]="pradeep";
	char b[10]="kumar";
	strcat(a," ");
	strcat(a,b);
	printf("string:%s",a);
}
