#include<stdio.h>
int main()
{
	int i;
	int a[]={1,2,3,4,5,6};
	for(i=5;i>=0;i--)
	{
		printf("%d",a[i]);
	}
	
}
