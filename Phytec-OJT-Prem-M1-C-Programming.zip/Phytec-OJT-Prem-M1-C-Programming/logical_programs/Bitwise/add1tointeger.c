#include <stdio.h>

int main() {
    int num = 5;

    
    num++;  

    printf("Result: %d\n", num); // Output: 6

    return 0;
}

