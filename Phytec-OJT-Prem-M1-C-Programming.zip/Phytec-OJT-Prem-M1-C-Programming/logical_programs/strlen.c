#include<stdio.h>
#include<string.h>
int main()
{
	int l;
	char a[]={"pradeep kumar"};
	l=strlen(&a[0]);
	printf("length is %d",l);
}
