#include <stdio.h>
enum option  {false,true};
int main() 
{
    enum option var;
    var =true;
    printf("%d",var);

    return 0;
}
