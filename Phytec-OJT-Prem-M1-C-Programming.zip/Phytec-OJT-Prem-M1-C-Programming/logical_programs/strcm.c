#include<stdio.h>
#include<string.h>
int main()
{
	int c;
	char a[30]="pradeep";
	char b[20]="kumar";
	c=strcmp(a,b);
	printf("comparision is %d",c);
}

