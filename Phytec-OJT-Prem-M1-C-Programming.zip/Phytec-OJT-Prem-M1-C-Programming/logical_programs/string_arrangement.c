#include<stdio.h>
int main()
{
	char name[30];
	printf("Enter name of the string: ");
	scanf("%s",name);
	printf("%d",name[1]);

}
