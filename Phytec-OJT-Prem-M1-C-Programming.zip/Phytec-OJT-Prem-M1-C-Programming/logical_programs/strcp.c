#include<stdio.h>
#include<string.h>
int main()
{

	
	char a[]={"pradeep"};
	char b[]={"kumar"};
	strcpy(a,b);
       	printf("copied string is %s",a);
}	

	
