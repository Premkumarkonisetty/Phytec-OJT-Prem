#include<stdio.h>
int main()
{
	int num,sum=0,res;
	printf("Enter number: ");
	scanf("%d",&num);
	while(num)
	{
		res=num%10;
		sum=sum+res;
		num=num/10;
	}
	printf("the sum is: %d",sum);
}
