#include<stdio.h>
int main()
{
	int i,j,num,temp=0;
	printf("Enter the size: ");
	scanf("%d",&num);
	int a[num];
	for(i=0;i<num;i++)
	{
		printf("Enter number %d: ",i+1);
		scanf("%d",&a[i]);
	}

	for(i=0;i<num;i++)
	{
		for(j=i+1;j<num;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	printf("The assending order is: ");
	for(i=0;i<num;i++)
	{
		printf("%d\t",a[i]);
	}
	
	printf("The desending order is: ");
	for(i=num;i>0;i--)
	{
		printf("%d\t",a[i]);
	}
}
