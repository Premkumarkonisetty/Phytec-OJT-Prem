#include<stdio.h>
int main()
{
        int i,range;
        printf("Enter the range of odd numbers: ");
        scanf("%d",&range);
        printf("The odd numbers are: ");
        for(i=1;i<=range;i++)
        {
                if(i%2!=0)
                printf("\n%d\n",i);
        }
}

