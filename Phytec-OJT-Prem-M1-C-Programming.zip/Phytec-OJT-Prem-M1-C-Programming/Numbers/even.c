#include<stdio.h>
int main()
{
        int i,range;
        printf("Enter the range of Even numbers: ");
        scanf("%d",&range);
        printf("The Even numbers are: ");
        for(i=1;i<=range;i++)
        {
		if(i%2==0)
                printf("\n%d\n",i);
        }
}

