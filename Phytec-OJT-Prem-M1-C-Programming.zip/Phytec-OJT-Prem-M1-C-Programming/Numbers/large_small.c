#include<stdio.h>
int main()
{
	int a=4,b=2,c=7,d=6;
	if(a>b&&a>c&&a>d)
	
		printf("a is bigger");
	else if(b>c&&b>d)
		printf("b is bigger");
	else if(c>d)
		printf("c is bigger");
	else
		printf("d is bigger");
	
	if(a<b&&a<c&&a<d)
	
                printf("a is smaller");
        else if(b<c&&b<d)
                printf("b is smaller");
        else if(c<d)
                printf("c is smaller");
        else
                printf("d is smaller");
	

}i
