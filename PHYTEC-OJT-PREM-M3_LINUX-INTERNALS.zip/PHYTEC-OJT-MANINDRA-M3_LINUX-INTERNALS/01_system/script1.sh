#!/bin/bash
date
pwd
whoami
echo "Bye bye from script"

